package com.crow.rally

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Releases are published by the repository's GitHub Actions workflow.
 * Never installs arbitrary APKs: owner/repository, SHA-256, package, signer and
 * monotonic version code must all match. Android always asks for installation consent.
 */
class RallyUpdater(
    private val activity: Activity,
    private val status: (String) -> Unit
) {
    private val busy = AtomicBoolean(false)
    private val api = "https://api.github.com/repos/riamanet/RallyBot/releases/latest"
    private val apkName = "RallyBot.apk"

    private data class Release(
        val title: String,
        val versionCode: Long,
        val tag: String,
        val apkUrl: String,
        val sha256: String,
        val notes: String
    )

    private fun showStatus(message: String) {
        activity.runOnUiThread { status(message) }
    }

    fun checkForUpdate(manual: Boolean) {
        if (!busy.compareAndSet(false, true)) return
        if (manual) showStatus("업데이트 확인 중…")
        Thread {
            try {
                val connection = openConnection(api)
                val json = try {
                    if (connection.responseCode == 404) {
                        showStatus(if (manual) "아직 공개된 업데이트가 없어요." else "")
                        return@Thread
                    }
                    require(connection.responseCode == 200) { "GitHub 오류 ${connection.responseCode}" }
                    JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                } finally { connection.disconnect() }
                val release = parseRelease(json)
                val installedCode = installedVersionCode()
                if (release.versionCode <= installedCode) {
                    showStatus(if (manual) "최신 버전 사용 중 (${versionName()})" else "")
                } else {
                    showStatus("새 버전: ${release.title}")
                    activity.runOnUiThread { updateDialog(release) }
                }
            } catch (e: Exception) {
                if (manual) showStatus("업데이트 확인 실패: ${e.localizedMessage ?: "네트워크 오류"}")
            } finally { busy.set(false) }
        }.start()
    }

    private fun parseRelease(json: JSONObject): Release {
        val tag = json.getString("tag_name")
        val match = Regex("^v1\\.0\\.(\\d+)$").matchEntire(tag)
            ?: throw IllegalArgumentException("알 수 없는 업데이트 버전: $tag")
        val runNumber = match.groupValues[1].toLong()
        require(runNumber in 1..1_000_000) { "잘못된 업데이트 번호" }
        val assets = json.getJSONArray("assets")
        var url: String? = null
        var sha256: String? = null
        for (i in 0 until assets.length()) {
            val asset = assets.getJSONObject(i)
            if (asset.optString("name") == apkName) {
                url = asset.getString("browser_download_url")
                val raw = asset.optString("digest")
                if (raw.startsWith("sha256:", ignoreCase = true)) sha256 = raw.substringAfter(':')
            }
        }
        val uri = Uri.parse(url ?: throw IllegalArgumentException("APK 파일이 없어요"))
        require(uri.scheme == "https" && uri.host == "github.com"
            && uri.path?.startsWith("/riamanet/RallyBot/releases/download/$tag/") == true
            && uri.lastPathSegment == apkName) { "올바른 GitHub 다운로드 주소가 아니에요" }
        require(sha256?.matches(Regex("[a-fA-F0-9]{64}")) == true) { "APK 검증값이 없어요" }
        return Release(
            title = json.optString("name", tag),
            versionCode = 10000L + runNumber,
            tag = tag,
            apkUrl = uri.toString(),
            sha256 = sha256!!.lowercase(Locale.US),
            notes = json.optString("body", "").take(500)
        )
    }

    private fun versionName(): String = activity.packageManager
        .getPackageInfo(activity.packageName, 0).versionName ?: "?"

    private fun installedVersionCode(): Long = activity.packageManager
        .getPackageInfo(activity.packageName, 0).longVersionCode

    private fun updateDialog(release: Release) {
        if (activity.isFinishing || activity.isDestroyed) return
        val explanation = if (release.notes.isBlank()) "새 버전이 나왔어요. 설치할까요?" else
            "새 버전이 나왔어요.\n\n${release.notes}"
        AlertDialog.Builder(activity)
            .setTitle("RallyBot 업데이트 · ${release.tag}")
            .setMessage(explanation)
            .setNegativeButton("나중에", null)
            .setPositiveButton("업데이트") { _, _ -> requestDownload(release) }
            .show()
    }

    private fun requestDownload(release: Release) {
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity)
                .setTitle("앱 업데이트 권한")
                .setMessage("안드로이드에서 RallyBot의 '이 출처 허용'을 켠 뒤 앱으로 돌아와 업데이트 버튼을 다시 눌러주세요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("설정 열기") { _, _ ->
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}")))
                }.show()
            return
        }
        if (!busy.compareAndSet(false, true)) return
        showStatus("APK 다운로드 준비 중…")
        Thread {
            try {
                val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
                val file = File(dir, "RallyBot-update.apk")
                if (file.exists()) file.delete()
                val connection = openConnection(release.apkUrl)
                try {
                    require(connection.responseCode == 200) { "다운로드 오류 ${connection.responseCode}" }
                    val total = connection.contentLengthLong
                    var downloaded = 0L
                    var lastPercent = -1
                    val digest = MessageDigest.getInstance("SHA-256")
                    connection.inputStream.use { input ->
                        file.outputStream().buffered().use { output ->
                            val buffer = ByteArray(65536)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                downloaded += count
                                require(downloaded <= 150L * 1024 * 1024) { "APK 크기가 너무 커요" }
                                output.write(buffer, 0, count)
                                digest.update(buffer, 0, count)
                                if (total > 0) {
                                    val percent = (downloaded * 100 / total).toInt()
                                    if (percent / 10 != lastPercent / 10) {
                                        lastPercent = percent
                                        showStatus("APK 다운로드 ${percent}%")
                                    }
                                }
                            }
                        }
                    }
                    val actual = digest.digest().joinToString("") { "%02x".format(it) }
                    require(actual.equals(release.sha256, true)) { "APK 무결성 검사 실패" }
                    verifyApk(file, release.versionCode)
                    activity.runOnUiThread { launchInstaller(file) }
                } finally { connection.disconnect() }
            } catch (e: SecurityException) {
                showStatus("업데이트 설치 불가: ${e.localizedMessage ?: "서명 오류"}")
                activity.runOnUiThread { mismatchDialog() }
            } catch (e: Exception) {
                showStatus("업데이트 실패: ${e.localizedMessage ?: "파일 오류"}")
            } finally { busy.set(false) }
        }.start()
    }

    private fun verifyApk(file: File, expectedCode: Long) {
        @Suppress("DEPRECATION")
        val archive = activity.packageManager.getPackageArchiveInfo(
            file.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES)
            ?: throw IllegalArgumentException("APK 내용을 읽을 수 없어요")
        @Suppress("DEPRECATION")
        val installed = activity.packageManager.getPackageInfo(
            activity.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        require(archive.packageName == activity.packageName) { "다른 앱의 APK입니다" }
        require(archive.longVersionCode == expectedCode && expectedCode > installed.longVersionCode) {
            "새 버전 번호가 올바르지 않아요"
        }
        val oldSigners = installed.signingInfo?.apkContentsSigners ?: emptyArray()
        val newSigners = archive.signingInfo?.apkContentsSigners ?: emptyArray()
        if (oldSigners.isEmpty() || newSigners.isEmpty() ||
            oldSigners.size != newSigners.size ||
            oldSigners.zip(newSigners).any { (a, b) -> !a.toByteArray().contentEquals(b.toByteArray()) }) {
            throw SecurityException("기존 APK와 새 APK 서명이 달라요")
        }
    }

    private fun mismatchDialog() {
        AlertDialog.Builder(activity)
            .setTitle("최초 업데이트 서명 변경")
            .setMessage("기존 시험용 앱과 새 고정 서명 버전이 달라서 덮어쓰기가 안 됩니다. 이번 한 번은 기존 RallyBot을 제거한 다음 새 버전을 설치하고 + 위치를 다시 등록해야 해요. 다음 버전부터는 덮어쓰기 업데이트가 가능합니다.")
            .setNegativeButton("닫기", null)
            .setPositiveButton("GitHub 설치 페이지") { _, _ ->
                activity.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://github.com/riamanet/RallyBot/releases/latest")))
            }.show()
    }

    private fun launchInstaller(file: File) {
        if (activity.isFinishing || activity.isDestroyed) return
        val contentUri = FileProvider.getUriForFile(
            activity, activity.packageName + ".updatefiles", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            activity.startActivity(intent)
            showStatus("설치 화면에서 업데이트를 승인해 주세요.")
        } catch (e: Exception) {
            showStatus("설치 화면 열기 실패: ${e.localizedMessage ?: "오류"}")
        }
    }

    private fun openConnection(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "RallyBot-Android-Updater")
            setRequestProperty("Accept", "application/vnd.github+json")
        }
}
