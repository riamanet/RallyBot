package com.crow.rally

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestProjection = 1021
    private val prefs by lazy { getSharedPreferences("rally_settings", MODE_PRIVATE) }
    private lateinit var levelField: EditText
    private lateinit var statusText: TextView
    private val dark = Color.rgb(15, 20, 30)
    private val panel = Color.rgb(27, 36, 51)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark

        val scroll = ScrollView(this).apply { setBackgroundColor(dark) }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(40), dp(22), dp(36))
        }
        scroll.addView(layout)
        setContentView(scroll)

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        brand.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(74), dp(74)))
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        header.addView(label("RallyBot", 27, Color.WHITE, true))
        header.addView(label("도적보스 자동 집결", 14, 0xFFAFBBD1.toInt()))
        brand.addView(header)
        layout.addView(brand)

        layout.addView(label("게임 화면을 켜두면 도적보스 집결만 확인해 조건에 맞을 때 참여합니다.", 14, 0xFFAFBBD1.toInt()))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(panel, 18)
            val p = LinearLayout.LayoutParams(-1, -2)
            p.topMargin = dp(28)
            layout.addView(this, p)
        }
        card.addView(label("도적보스 몇 레벨 이하 잡기", 16, Color.WHITE, true))
        levelField = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("max_level", 70).toString())
            setTextColor(Color.WHITE)
            textSize = 32f
            setSingleLine(true)
            setSelectAllOnFocus(true)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF8095B8.toInt())
        }
        card.addView(levelField)
        card.addView(label("예: 70 입력 → 도적보스 Lv.70까지 참여, 75는 제외", 12, 0xFFAFBBD1.toInt()))

        val save = button("레벨 설정 저장", 0xFF35445C.toInt()) {
            saveLevel()
        }
        layout.addView(save, btnParams())

        val accessBtn = button("① 접근성 권한 설정", 0xFF35445C.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        layout.addView(accessBtn, btnParams())

        val start = button("② 화면 공유 후 자동 집결 시작", 0xFF397ACC.toInt()) {
            if (!saveLevel()) return@button
            if (TapService.instance == null) {
                Toast.makeText(this, "먼저 접근성에서 '도적보스 자동 집결'을 허용해 주세요.", Toast.LENGTH_LONG).show()
                return@button
            }
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), requestProjection)
        }
        layout.addView(start, btnParams())
        layout.addView(button("자동 집결 중지", 0xFF813C46.toInt()) {
            startService(Intent(this, RallyService::class.java).setAction(RallyService.ACTION_STOP))
            refreshStatus()
        }, btnParams())

        statusText = label("", 13, 0xFFC2D1E9.toInt())
        statusText.setPadding(0, dp(24), 0, dp(6))
        layout.addView(statusText)
        layout.addView(label("※ 화면 켜짐 · 세로 모드 · 게임 실행 상태에서만 동작합니다.\n※ 이름이나 레벨이 불확실하면 누르지 않습니다.\n※ 첫 버전은 제공된 화면 배치 기준이며 실제 기기 테스트가 필요합니다.\n※ 게임 운영 정책에서 자동 조작을 제한할 수 있습니다.", 12, 0xFF93A2B8.toInt()))
        refreshStatus()
    }

    override fun onResume() { super.onResume(); if (::statusText.isInitialized) refreshStatus() }

    private fun refreshStatus() {
        val running = prefs.getBoolean("running", false)
        val last = prefs.getString("status", "대기 중")
        statusText.text = "상태: ${if (running) "실행 중" else "중지"}\n마지막 동작: $last"
    }

    private fun saveLevel(): Boolean {
        val level = levelField.text.toString().toIntOrNull()
        if (level == null || level < 50 || level > 999) {
            Toast.makeText(this, "50~999 사이의 레벨을 입력해 주세요.", Toast.LENGTH_LONG).show()
            return false
        }
        prefs.edit().putInt("max_level", level).apply()
        Toast.makeText(this, "도적보스 Lv.$level 이하로 저장했어요.", Toast.LENGTH_SHORT).show()
        return true
    }

    @Deprecated("Uses MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestProjection) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "화면 공유가 취소됐어요.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RallyService::class.java).apply {
            action = RallyService.ACTION_START
            putExtra("resultCode", resultCode)
            putExtra("projectionData", data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "이제 게임 화면으로 이동해 주세요.", Toast.LENGTH_LONG).show()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun label(content: String, sp: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = content; textSize = sp.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        gravity = Gravity.START
        setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun button(content: String, color: Int, callback: () -> Unit) = Button(this).apply {
        text = content; textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(color, 12)
        setOnClickListener { callback() }
    }
    private fun btnParams() = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) }
}
