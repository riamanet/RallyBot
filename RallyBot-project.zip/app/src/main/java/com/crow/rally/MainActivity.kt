package com.crow.rally

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.content.res.ColorStateList
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestProjection = 1021
    private val prefs by lazy { getSharedPreferences("rally_settings", MODE_PRIVATE) }
    private lateinit var levelField: EditText
    private lateinit var statusText: TextView
    private lateinit var updateText: TextView
    private lateinit var updater: RallyUpdater
    private val dark = Color.rgb(15, 20, 30)
    private val panel = Color.rgb(27, 36, 51)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark

        val scroll = ScrollView(this).apply { setBackgroundColor(dark) }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(40), dp(22), dp(36))
        }
        scroll.addView(layout)
        setContentView(scroll)

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        brand.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(74), dp(74)))
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        header.addView(label("RallyBot", 27, Color.WHITE, true))
        header.addView(label("도적보스 자동 집결", 14, 0xFFAFBBD1.toInt()))
        brand.addView(header)
        layout.addView(brand)

        layout.addView(label("게임 화면을 켜두면 도적보스 집결만 확인해 조건에 맞을 때 참여합니다.", 14, 0xFFAFBBD1.toInt()))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(panel, 18)
            val p = LinearLayout.LayoutParams(-1, -2)
            p.topMargin = dp(28)
            layout.addView(this, p)
        }
        card.addView(label("도적보스 레벨", 16, Color.WHITE, true))
        levelField = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("max_level", 70).toString())
            setTextColor(Color.WHITE)
            textSize = 32f
            setSingleLine(true)
            setSelectAllOnFocus(true)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF8095B8.toInt())
        }
        card.addView(levelField)
        card.addView(label("설정한 레벨 이하의 도적보스 집결에만 자동 참여합니다.", 12, 0xFFAFBBD1.toInt()))

        // This controls when a verified, eligible rally is joined. It does
        // not slow down OCR or the deployment confirmation sequence.
        val speedCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = rounded(panel, 18)
        }
        val speedCardParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        layout.addView(speedCard, speedCardParams)
        speedCard.addView(label("반응속도", 16, Color.WHITE, true))
        val modes = listOf("fast" to "빠름", "normal" to "보통", "slow" to "느림")
        val speedGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val savedSpeed = prefs.getString("response_speed", "fast") ?: "fast"
        modes.forEach { (mode, title) ->
            val radio = RadioButton(this).apply {
                id = View.generateViewId()
                tag = mode
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
                buttonTintList = ColorStateList.valueOf(0xFF88B7FA.toInt())
                isChecked = mode == savedSpeed
                setPadding(0, dp(6), 0, dp(6))
            }
            speedGroup.addView(radio, RadioGroup.LayoutParams(0, -2).apply { weight = 1f })
        }
        speedGroup.setOnCheckedChangeListener { group, checkedId ->
            val mode = group.findViewById<RadioButton>(checkedId)?.tag as? String
                ?: return@setOnCheckedChangeListener
            prefs.edit().putString("response_speed", mode).apply()
        }
        speedCard.addView(speedGroup)
        speedCard.addView(label(
            "빠름: 기존 속도  ·  보통: 1~5초  ·  느림: 10~20초",
            12, 0xFFAFBBD1.toInt()))
        speedCard.addView(label(
            "집결 참여 직전에 매번 랜덤 대기합니다. 기다리는 동안 집결이 사라지면 참여하지 않으며, 감지 회피를 보장하지 않습니다.",
            12, 0xFF93A2B8.toInt()))

        val save = button("레벨 설정 저장", 0xFF35445C.toInt()) {
            saveLevel()
        }
        layout.addView(save, btnParams())

        val accessBtn = button("① 접근성 권한 설정", 0xFF35445C.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        layout.addView(accessBtn, btnParams())

        layout.addView(button("② + 위치 등록 / 재설정", 0xFF35445C.toInt()) {
            val tapper = TapService.instance
            if (tapper == null) {
                Toast.makeText(this, "먼저 접근성 권한을 허용해 주세요.", Toast.LENGTH_LONG).show()
            } else {
                tapper.startPlusCalibration()
                Toast.makeText(this, "게임의 집결 목록으로 가서 떠 있는 버튼을 눌러주세요.", Toast.LENGTH_LONG).show()
            }
        }, btnParams())

        val start = button("③ 화면 공유 후 자동 집결 시작", 0xFF397ACC.toInt()) {
            if (!saveLevel()) return@button
            if (!prefs.getBoolean("plus_calibrated", false)) {
                Toast.makeText(this, "먼저 게임의 + 위치를 등록해 주세요.", Toast.LENGTH_LONG).show()
                return@button
            }
            if (TapService.instance == null) {
                Toast.makeText(this, "먼저 접근성에서 '도적보스 자동 집결'을 허용해 주세요.", Toast.LENGTH_LONG).show()
                return@button
            }
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), requestProjection)
        }
        layout.addView(start, btnParams())
        layout.addView(button("자동 집결 중지", 0xFF813C46.toInt()) {
            startService(Intent(this, RallyService::class.java).setAction(RallyService.ACTION_STOP))
            refreshStatus()
        }, btnParams())

        val installedVersion = packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
        layout.addView(label("앱 버전: $installedVersion", 13, 0xFFAFBBD1.toInt()))
        updateText = label("업데이트 확인 전", 13, 0xFFC2D1E9.toInt())
        updateText.setPadding(0, dp(8), 0, dp(6))
        layout.addView(updateText)
        updater = RallyUpdater(this) { message -> updateText.text = message }
        layout.addView(button("새 버전 확인 / 업데이트", 0xFF35445C.toInt()) {
            updater.checkForUpdate(manual = true)
        }, btnParams())

        statusText = label("", 13, 0xFFC2D1E9.toInt())
        statusText.setPadding(0, dp(24), 0, dp(6))
        layout.addView(statusText)
        layout.addView(label("※ 화면 켜짐 · 세로 모드 · 게임 실행 상태에서만 동작합니다.\n※ 이름이나 레벨이 불확실하면 누르지 않습니다.\n※ 첫 집결의 오른쪽 + 위치만 등록하며 줄 간격은 화면에서 추정합니다.\n※ 게임 운영 정책에서 자동 조작을 제한할 수 있습니다.", 12, 0xFF93A2B8.toInt()))
        refreshStatus()
        updater.checkForUpdate(manual = false)
    }

    override fun onResume() { super.onResume(); if (::statusText.isInitialized) refreshStatus() }

    private fun refreshStatus() {
        val running = prefs.getBoolean("running", false)
        val last = prefs.getString("status", "대기 중")
        val registered = if (prefs.getBoolean("plus_calibrated", false)) "등록 완료" else "미등록"
        val ocrMs = prefs.getLong("last_level_ocr_ms", -1L)
        val ocrLine = if (ocrMs >= 0) "${ocrMs}ms" else "아직 측정 안 됨"
        statusText.text = "상태: ${if (running) "실행 중" else "중지"}\n+ 위치: $registered\n최근 레벨 인식: $ocrLine\n마지막 동작: $last"
    }

    private fun saveLevel(): Boolean {
        val level = levelField.text.toString().toIntOrNull()
        if (level == null || level < 5 || level > 999) {
            Toast.makeText(this, "5~999 사이의 최대 레벨을 입력해 주세요.", Toast.LENGTH_LONG).show()
            return false
        }
        prefs.edit().putInt("max_level", level).apply()
        Toast.makeText(this, "도적보스 Lv.$level 이하로 저장했어요.", Toast.LENGTH_SHORT).show()
        return true
    }

    @Deprecated("Uses MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestProjection) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "화면 공유가 취소됐어요.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, RallyService::class.java).apply {
            action = RallyService.ACTION_START
            putExtra("resultCode", resultCode)
            putExtra("projectionData", data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "이제 게임 화면으로 이동해 주세요.", Toast.LENGTH_LONG).show()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun label(content: String, sp: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = content; textSize = sp.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        gravity = Gravity.START
        setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun button(content: String, color: Int, callback: () -> Unit) = Button(this).apply {
        text = content; textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(color, 12)
        setOnClickListener { callback() }
    }
    private fun btnParams() = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) }
}
