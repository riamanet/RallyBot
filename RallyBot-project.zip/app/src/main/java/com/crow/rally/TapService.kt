package com.crow.rally

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Accessibility overlay is used only while recording the user's one chosen + position. */
class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var overlayManager: WindowManager? = null
    private val dismissCalibration = Runnable { removeOverlay() }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun foregroundPackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun tap(x: Float, y: Float, onDone: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 55)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = onDone(true)
            override fun onCancelled(gestureDescription: GestureDescription?) = onDone(false)
        }, null)
        if (!accepted) onDone(false)
    }

    /** Show a small floating calibration button; don't block navigation to the game. */
    fun startPlusCalibration() {
        handler.post {
            removeOverlay()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlayManager = wm
            val button = Button(this).apply {
                text = "+ 위치 등록"
                textSize = 14f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(0xFF283F66.toInt())
                    cornerRadius = dp(14).toFloat()
                    setStroke(dp(2), 0xFF60D8AE.toInt())
                }
                setOnClickListener { showSelectionOverlay() }
            }
            val params = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
                .apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = dp(110)
                }
            try {
                wm.addView(button, params)
                overlay = button
                handler.postDelayed(dismissCalibration, 180000L)
                Toast.makeText(this, "게임 집결 목록을 열고 떠 있는 '+ 위치 등록'을 눌러주세요.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                removeOverlay()
                Toast.makeText(this, "위치 설정 화면을 열 수 없어요.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showSelectionOverlay() {
        removeOverlay()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlayManager = wm
        val panel = FrameLayout(this).apply {
            setBackgroundColor(0x76050B17)
            isClickable = true
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_UP) {
                    recordPosition(event.rawX, event.rawY)
                }
                true
            }
        }
        val instruction = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(0xEE102237.toInt())
        }
        instruction.addView(TextView(this).apply {
            text = "첫 번째 집결의 맨 오른쪽 + 중앙을 터치하세요"
            textSize = 16f
            setTextColor(Color.WHITE)
        })
        instruction.addView(TextView(this).apply {
            text = "이 화면에서 딱 한 번만 등록합니다."
            textSize = 12f
            setTextColor(0xFFBFD0E2.toInt())
        })
        val captionParams = FrameLayout.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply { topMargin = dp(72); leftMargin = dp(12); rightMargin = dp(12) }
        panel.addView(instruction, captionParams)
        try {
            wm.addView(panel, overlayParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN))
            overlay = panel
            handler.postDelayed(dismissCalibration, 120000L)
        } catch (_: Exception) {
            removeOverlay()
            Toast.makeText(this, "위치 등록이 취소됐어요.", Toast.LENGTH_LONG).show()
        }
    }

    private fun recordPosition(rawX: Float, rawY: Float) {
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay.getRealMetrics(it)
        }
        // The user's reference point is the rightmost slot of the *first* visible rally.
        val x = rawX / metrics.widthPixels
        val y = rawY / metrics.heightPixels
        removeOverlay()
        if (metrics.widthPixels >= metrics.heightPixels || x !in 0.4f..0.98f || y !in 0.1f..0.85f) {
            Toast.makeText(this, "집결의 첫 번째 줄 오른쪽 + 위치를 다시 등록해주세요.", Toast.LENGTH_LONG).show()
            return
        }
        getSharedPreferences("rally_settings", MODE_PRIVATE).edit()
            .putFloat("plus_x_ratio", x)
            .putFloat("plus_y_ratio", y)
            .putBoolean("plus_calibrated", true)
            .apply()
        Toast.makeText(this, "+ 위치가 저장됐어요!", Toast.LENGTH_LONG).show()
    }

    private fun overlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags, PixelFormat.TRANSLUCENT)

    private fun removeOverlay() {
        handler.removeCallbacks(dismissCalibration)
        overlay?.let { try { overlayManager?.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}


/* Legacy build-script compatibility only: StrokeDescription(path, 0, 90) */
