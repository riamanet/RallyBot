package com.crow.rally

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.nio.ByteBuffer
import kotlin.math.max

/**
 * Screen-only, fail-closed automation.
 * Visual coordinates are normalized to the user's 709x1536 portrait screenshots.
 * Does not send screen content, access the game's network requests, or alter game files.
 */
class RallyService : Service() {
    companion object {
        const val ACTION_START = "com.crow.rally.START"
        const val ACTION_STOP = "com.crow.rally.STOP"
        private const val CHANNEL = "rally_monitor"
        private const val NOTIFICATION_ID = 21
        private const val REF_W = 709
        private const val REF_H = 1536
    }

    private enum class Stage { WORLD, EVENT, DEPLOY }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("rally_settings", MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var capturing = false
    private var stage = Stage.WORLD
    private var lastActionAt = 0L
    private var stageEnteredAt = 0L
    private var previousAttempt = ""
    private var previousAttemptAt = 0L
    private var allowedGamePackage: String? = null
    private var displayWidth = 0
    private var displayHeight = 0
    private var projectionCallback: MediaProjection.Callback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring("사용자가 중지함")
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START || capturing) return START_NOT_STICKY
        startForeground(NOTIFICATION_ID, buildNotification())
        try {
            val grantCode = intent.getIntExtra("resultCode", 0)
            @Suppress("DEPRECATION")
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra("projectionData", Intent::class.java)
            } else intent.getParcelableExtra("projectionData")
            require(grantCode != 0 && data != null) { "화면 공유 승인 정보 없음" }

            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(grantCode, data)
            require(projection != null) { "화면 캡처 시작 실패" }
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() { stopMonitoring("화면 공유가 종료됨") }
            }
            projection!!.registerCallback(projectionCallback!!, handler)

            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            displayWidth = metrics.widthPixels
            displayHeight = metrics.heightPixels
            require(displayWidth < displayHeight) { "현재 버전은 세로 화면에서만 동작합니다" }

            reader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection!!.createVirtualDisplay(
                "rally-screen", displayWidth, displayHeight, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface, null, handler
            )
            capturing = true
            stage = Stage.WORLD
            stageEnteredAt = SystemClock.elapsedRealtime()
            allowedGamePackage = null
            prefs.edit().putBoolean("running", true).apply()
            setStatus("게임 화면 대기 중")
            handler.postDelayed(::scanFrame, 1700L)
        } catch (ex: Exception) {
            stopMonitoring("시작 실패: ${ex.message.orEmpty().take(70)}")
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "RallyBot 집결 감시", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = Intent(this, RallyService::class.java).setAction(ACTION_STOP)
        val stopAction = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openAction = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("RallyBot 실행 중")
            .setContentText("화면에서 집결을 확인하고 있어요")
            .setOngoing(true)
            .setContentIntent(openAction)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "중지", stopAction)
            .build()
    }

    private fun scanFrame() {
        if (!capturing) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 1100) { schedule(500); return }
        val frame = captureNormalizedFrame()
        if (frame == null) { schedule(500); return }

        when (stage) {
            Stage.WORLD -> {
                if (hasRallySkull(frame)) {
                    val packageName = TapService.instance?.foregroundPackage()
                    if (packageName != null && packageName != this.packageName &&
                        !packageName.startsWith("com.android.") &&
                        !packageName.startsWith("android")) {
                        if (allowedGamePackage == null) allowedGamePackage = packageName
                        if (allowedGamePackage == packageName) {
                            touch(651, 961) {
                                advance(Stage.EVENT)
                                setStatus("집결 아이콘 확인 → 목록 열기")
                            }
                        }
                    } else setStatus("접근성 권한/게임 화면 확인 필요")
                }
                frame.recycle()
                schedule(1050)
            }
            Stage.EVENT -> {
                if (!isEventBackground(frame)) {
                    if (now - stageEnteredAt > 6500) advance(Stage.WORLD)
                    frame.recycle()
                    schedule(1000)
                    return
                }
                // New rallies are surfaced by a yellow refresh button, not by the badge count.
                if (isRefreshVisible(frame)) {
                    touch(355, 1462) { setStatus("새 집결 알림 → 갱신") }
                    frame.recycle()
                    schedule(1650)
                    return
                }
                readText(frame) { text ->
                    val candidate = selectEligibleRally(text, frame)
                    if (candidate != null) {
                        val signature = "${candidate.level}:${candidate.rowY}:${candidate.plusX}"
                        val time = SystemClock.elapsedRealtime()
                        if (signature != previousAttempt || time - previousAttemptAt > 18000) {
                            previousAttempt = signature
                            previousAttemptAt = time
                            touch(candidate.plusX, candidate.plusY) {
                                advance(Stage.DEPLOY)
                                setStatus("Lv.${candidate.level} 도적보스 → + 버튼")
                            }
                        }
                    } else {
                        setStatus("조건에 맞는 도적보스 대기 중 (최대 Lv.${maxLevel()})")
                    }
                }
            }
            Stage.DEPLOY -> {
                if (now - stageEnteredAt > 12000L) {
                    // An unknown dialog or OCR failure is not permission to tap blindly.
                    setStatus("출정 화면 확인 실패 - 안전 대기")
                    frame.recycle()
                    schedule(2500)
                    return
                }
                readText(frame) { text ->
                    val hasDeploy = text.textBlocks.asSequence()
                        .flatMap { it.lines.asSequence() }
                        .any { normalize(it.text).contains("출정") }
                    if (hasDeploy && isBlueDeployButton(frame)) {
                        touch(357, 1169) {
                            advance(Stage.WORLD)
                            setStatus("출정 누름 → 월드맵 복귀 감시")
                        }
                    }
                }
            }
        }
    }

    private fun schedule(delay: Long) { if (capturing) handler.postDelayed(::scanFrame, delay) }

    private fun advance(next: Stage) {
        stage = next
        stageEnteredAt = SystemClock.elapsedRealtime()
    }

    private fun touch(x: Int, y: Int, success: () -> Unit) {
        val tapper = TapService.instance ?: run { setStatus("접근성 서비스가 꺼짐"); return }
        val foreground = tapper.foregroundPackage()
        if (allowedGamePackage == null || foreground != allowedGamePackage) {
            setStatus("다른 앱이 전면에 있어 터치 중지")
            return
        }
        // Only one gesture at a time; a lost frame must not cause rapid repeated taps.
        lastActionAt = SystemClock.elapsedRealtime()
        tapper.tap(x / REF_W.toFloat() * displayWidth, y / REF_H.toFloat() * displayHeight) { ok ->
            if (ok) success() else setStatus("자동 터치 실패")
        }
    }

    private data class Candidate(val level: Int, val rowY: Int, val plusX: Int, val plusY: Int)
    private fun selectEligibleRally(result: Text, bitmap: Bitmap): Candidate? {
        val lines = result.textBlocks.flatMap { it.lines }
        val levelPattern = Regex("(?i)lv\\s*[.:：]?\\s*(\\d{2,3})")
        val candidates = mutableListOf<Candidate>()
        for (line in lines) {
            val box = line.boundingBox ?: continue
            val match = levelPattern.find(normalize(line.text)) ?: continue
            val level = match.groupValues[1].toIntOrNull() ?: continue
            if (level < 50 || level % 5 != 0 || level > maxLevel()) continue
            val rowY = box.centerY()
            // Nearby lines can be split by OCR, but must be in this same header row.
            val nearby = lines.filter {
                val other = it.boundingBox
                other != null && kotlin.math.abs(other.centerY() - rowY) < 28
            }.joinToString(" ") { normalize(it.text) }
            if (!nearby.contains("도적보스")) continue
            val plus = findVisiblePlus(bitmap, rowY) ?: continue
            candidates += Candidate(level, rowY, plus.first, plus.second)
        }
        // Preserve the displayed order; never substitute 'any rally' if OCR fails.
        return candidates.minByOrNull { it.rowY }
    }

    private fun findVisiblePlus(bitmap: Bitmap, headerY: Int): Pair<Int, Int>? {
        val expectedY = headerY + 148
        // Each empty member slot has a bright green cross; only tap one inside the verified row.
        var best: Pair<Int, Int>? = null
        var bestGreen = 0
        for (y in (expectedY - 24)..(expectedY + 24) step 8) {
            for (x in listOf(620, 530, 440, 349)) {
                if (x < 20 || x > REF_W - 20 || y < 20 || y > REF_H - 20) continue
                var green = 0
                for (yy in y - 16..y + 16 step 2) {
                    for (xx in x - 16..x + 16 step 2) {
                        val c = bitmap.getPixel(xx, yy)
                        if (Color.green(c) > 130 &&
                            Color.green(c) > Color.red(c) + 50 &&
                            Color.green(c) > Color.blue(c) + 20) green++
                    }
                }
                if (green > bestGreen) {
                    bestGreen = green
                    best = x to y
                }
            }
        }
        return if (bestGreen > 100) best else null
    }

    private fun normalize(text: String) = text.replace(" ", "").replace("\n", "").trim()
    private fun maxLevel(): Int = prefs.getInt("max_level", 70)

    private fun hasRallySkull(bitmap: Bitmap): Boolean {
        var red = 0
        var light = 0
        var total = 0
        for (y in 930..989 step 3) for (x in 614..686 step 3) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 135 && r > g * 1.4f && r > b * 1.25f) red++
            if (r > 205 && g > 190 && b > 180) light++
            total++
        }
        return red > total * 0.22 && light > total * 0.07
    }

    private fun isEventBackground(bitmap: Bitmap): Boolean {
        // The event list has a large, pale blue/gray background absent on the world map.
        var score = 0
        for ((x, y) in listOf(355 to 700, 355 to 830, 355 to 1060, 355 to 1300)) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 165 && g > 173 && b > 180 && kotlin.math.abs(r - g) < 27) score++
        }
        return score >= 3
    }

    private fun isRefreshVisible(bitmap: Bitmap): Boolean {
        var yellow = 0
        for (y in 1440..1490 step 5) for (x in 280..425 step 5) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 210 && g in 125..220 && b < 105) yellow++
        }
        return yellow > 100
    }

    private fun isBlueDeployButton(bitmap: Bitmap): Boolean {
        var good = 0
        for ((x, y) in listOf(250 to 1167, 285 to 1183, 350 to 1137,
            430 to 1177, 468 to 1167)) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (b > 170 && b > g + 40 && g > r + 45 && r < 130) good++
        }
        return good >= 4
    }

    private fun readText(bitmap: Bitmap, callback: (Text) -> Unit) {
        // ML Kit reads bitmap asynchronously: it MUST remain alive until task completion.
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { if (capturing) callback(it) }
            .addOnFailureListener { setStatus("문자 인식 실패 - 건너뛰기") }
            .addOnCompleteListener {
                bitmap.recycle()
                schedule(if (stage == Stage.EVENT) 1700 else 1400)
            }
    }

    private fun captureNormalizedFrame(): Bitmap? {
        val image = try { reader?.acquireLatestImage() } catch (_: Exception) { null } ?: return null
        try {
            val plane = image.planes.firstOrNull() ?: return null
            val rowPadding = plane.rowStride - plane.pixelStride * image.width
            val paddedWidth = image.width + rowPadding / plane.pixelStride
            val tmp = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            val buffer: ByteBuffer = plane.buffer
            buffer.rewind()
            tmp.copyPixelsFromBuffer(buffer)
            val actual = Bitmap.createBitmap(tmp, 0, 0, image.width, image.height)
            tmp.recycle()
            val scaled = Bitmap.createScaledBitmap(actual, REF_W, REF_H, true)
            if (actual !== scaled) actual.recycle()
            return scaled
        } catch (_: Exception) {
            return null
        } finally { image.close() }
    }

    private fun setStatus(message: String) {
        prefs.edit().putString("status", message).apply()
    }

    private fun stopMonitoring(reason: String) {
        capturing = false
        handler.removeCallbacksAndMessages(null)
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        val oldProjection = projection
        projection = null
        try {
            projectionCallback?.let { oldProjection?.unregisterCallback(it) }
            oldProjection?.stop()
        } catch (_: Exception) {}
        projectionCallback = null
        prefs.edit().putBoolean("running", false).putString("status", reason).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (capturing || projection != null) stopMonitoring("서비스 종료")
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
