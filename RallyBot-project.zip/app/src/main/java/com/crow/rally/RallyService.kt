package com.crow.rally

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.nio.ByteBuffer
import kotlin.math.max

/**
 * Screen-only, fail-closed automation.
 * Visual coordinates are normalized to the user's 709x1536 portrait screenshots.
 * Does not send screen content, access the game's network requests, or alter game files.
 */
class RallyService : Service() {
    companion object {
        const val ACTION_START = "com.crow.rally.START"
        const val ACTION_STOP = "com.crow.rally.STOP"
        private const val CHANNEL = "rally_monitor"
        private const val NOTIFICATION_ID = 21
        private const val REF_W = 709
        private const val REF_H = 1536
    }

    private enum class Stage { WORLD, EVENT, DEPLOY }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("rally_settings", MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var capturing = false
    private var stage = Stage.WORLD
    private var lastActionAt = 0L
    private var stageEnteredAt = 0L
    private var previousAttempt = ""
    private var previousAttemptAt = 0L
    private var allowedGamePackage: String? = null
    private var displayWidth = 0
    private var displayHeight = 0
    private var projectionCallback: MediaProjection.Callback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring("사용자가 중지함")
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START || capturing) return START_NOT_STICKY
        startForeground(NOTIFICATION_ID, buildNotification())
        try {
            val grantCode = intent.getIntExtra("resultCode", 0)
            @Suppress("DEPRECATION")
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra("projectionData", Intent::class.java)
            } else intent.getParcelableExtra("projectionData")
            require(grantCode != 0 && data != null) { "화면 공유 승인 정보 없음" }

            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(grantCode, data)
            require(projection != null) { "화면 캡처 시작 실패" }
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() { stopMonitoring("화면 공유가 종료됨") }
            }
            projection!!.registerCallback(projectionCallback!!, handler)

            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            displayWidth = metrics.widthPixels
            displayHeight = metrics.heightPixels
            require(displayWidth < displayHeight) { "현재 버전은 세로 화면에서만 동작합니다" }

            reader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection!!.createVirtualDisplay(
                "rally-screen", displayWidth, displayHeight, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface, null, handler
            )
            capturing = true
            stage = Stage.WORLD
            stageEnteredAt = SystemClock.elapsedRealtime()
            allowedGamePackage = null
            prefs.edit().putBoolean("running", true).apply()
            setStatus("게임 화면 대기 중")
            handler.postDelayed(::scanFrame, 450L)
        } catch (ex: Exception) {
            stopMonitoring("시작 실패: ${ex.message.orEmpty().take(70)}")
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "RallyBot 집결 감시", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = Intent(this, RallyService::class.java).setAction(ACTION_STOP)
        val stopAction = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openAction = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("RallyBot 실행 중")
            .setContentText("화면에서 집결을 확인하고 있어요")
            .setOngoing(true)
            .setContentIntent(openAction)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "중지", stopAction)
            .build()
    }

    private fun scanFrame() {
        if (!capturing) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 300) { schedule(100); return }
        val frame = captureNormalizedFrame()
        if (frame == null) { schedule(150); return }

        when (stage) {
            Stage.WORLD -> {
                // A calibrated user often starts monitoring while the rally list
                // is already open. The old state machine watched only for the
                // world-map skull and therefore could never reach EVENT here.
                val foreground = TapService.instance?.foregroundPackage()
                val listVisible = isEventBackground(frame)
                val skullVisible = hasRallySkull(frame)
                // Never bind the permitted tap target to the launcher (or other app)
                // merely because it is foregrounded while the user switches to the game.
                // Pin only after the actual game UI is positively recognized.
                val gameVisible = foreground != null && foreground != packageName &&
                    !foreground.startsWith("com.android.") &&
                    !foreground.startsWith("android") &&
                    !foreground.contains("launcher", ignoreCase = true) &&
                    !foreground.contains("systemui", ignoreCase = true)
                if (gameVisible && (listVisible || skullVisible) && allowedGamePackage == null) {
                    allowedGamePackage = foreground
                    setStatus("게임 화면 확인됨, 집결 확인 시작")
                }
                if (listVisible) {
                    if (gameVisible && foreground == allowedGamePackage) {
                        advance(Stage.EVENT)
                        setStatus("이미 열린 집결 목록 인식 → 도적보스 확인")
                    } else {
                        setStatus("집결 목록 감지, 접근성/게임 전면 앱 확인 필요")
                    }
                } else if (skullVisible) {
                    if (gameVisible && foreground == allowedGamePackage) {
                        touch(651, 961) {
                            advance(Stage.EVENT)
                            setStatus("집결 아이콘 확인 → 목록 열기")
                        }
                    } else {
                        setStatus("해골 아이콘 감지, 접근성/게임 전면 앱 확인 필요")
                    }
                } else {
                    setStatus("게임 집결 화면 감지 대기 중 (전체 화면 공유 확인)")
                }
                frame.recycle()
                schedule(250)
            }
            Stage.EVENT -> {
                if (!isEventBackground(frame)) {
                    if (now - stageEnteredAt > 6500) advance(Stage.WORLD)
                    frame.recycle()
                    schedule(160)
                    return
                }
                // Recognize the refresh prompt without considering the notification badge.
                if (isRefreshVisible(frame)) {
                    touch(355, 1462) { setStatus("새 집결 알림 → 갱신") }
                    frame.recycle()
                    schedule(280)
                    return
                }
                readText(frame) { text, rows ->
                    if (stage != Stage.EVENT) return@readText
                    val candidate = selectEligibleRally(text, frame, rows)
                    if (candidate != null) {
                        val signature = "${candidate.level}:${candidate.rowY}:${candidate.plusX}"
                        val time = SystemClock.elapsedRealtime()
                        if (signature != previousAttempt || time - previousAttemptAt > 4500) {
                            touch(candidate.plusX, candidate.plusY) {
                                previousAttempt = signature
                                previousAttemptAt = SystemClock.elapsedRealtime()
                                advance(Stage.DEPLOY)
                                setStatus("Lv.${candidate.level} 도적보스 → 등록 위치 선택")
                            }
                        } else {
                            setStatus("동일 집결 재시도 대기 중")
                        }
                    }
                }
            }
            Stage.DEPLOY -> {
                // If a + tap did not open the troop panel, retry the list quickly.
                if (isEventBackground(frame) && now - stageEnteredAt > 1400L) {
                    advance(Stage.EVENT)
                    setStatus("편성 화면 지연 → 집결 재검사")
                    frame.recycle()
                    schedule(180)
                    return
                }
                if (now - stageEnteredAt > 4200L) {
                    // Never remain stuck forever if the + button was missed.
                    // Re-evaluate the current screen, but retain the retry
                    // cooldown to avoid repeated taps on a closed slot.
                    if (isEventBackground(frame)) {
                        advance(Stage.EVENT)
                        setStatus("편성 화면 미표시 → 집결 목록 다시 확인")
                    } else {
                        advance(Stage.WORLD)
                        setStatus("편성 화면 미표시 → 월드맵 다시 확인")
                    }
                    frame.recycle()
                    schedule(350)
                    return
                }
                readText(frame) { text, _ ->
                    val hasDeploy = text.textBlocks.asSequence()
                        .flatMap { it.lines.asSequence() }
                        .any { normalize(it.text).contains("출정") }
                    if (hasDeploy && isBlueDeployButton(frame)) {
                        touch(357, 1169) {
                            advance(Stage.WORLD)
                            setStatus("출정 누름 → 월드맵 복귀 감시")
                        }
                    }
                }
            }
        }
    }

    private fun schedule(delay: Long) { if (capturing) handler.postDelayed(::scanFrame, delay) }

    private fun advance(next: Stage) {
        stage = next
        stageEnteredAt = SystemClock.elapsedRealtime()
    }

    private fun touch(x: Int, y: Int, success: () -> Unit) {
        val tapper = TapService.instance ?: run { setStatus("접근성 서비스가 꺼짐"); return }
        val foreground = tapper.foregroundPackage()
        if (allowedGamePackage == null || foreground != allowedGamePackage) {
            setStatus("다른 앱이 전면에 있어 터치 중지")
            return
        }
        // Only one gesture at a time; a lost frame must not cause rapid repeated taps.
        lastActionAt = SystemClock.elapsedRealtime()
        tapper.tap(x / REF_W.toFloat() * displayWidth, y / REF_H.toFloat() * displayHeight) { ok ->
            if (ok) success() else setStatus("자동 터치 실패")
        }
    }

    private data class Candidate(val level: Int, val rowY: Int, val plusX: Int,
                                 val plusY: Int, val availableSlots: Int)

    /** Only the small "Lv.60" prefix goes to OCR; the monster covers part of its name. */
    private fun selectEligibleRally(result: Text, bitmap: Bitmap, rows: List<Int>): Candidate? {
        if (!prefs.getBoolean("plus_calibrated", false)) {
            setStatus("+ 위치가 등록되지 않음")
            return null
        }
        if (rows.isEmpty()) {
            setStatus("집결 카드 영역 인식 실패")
            return null
        }
        val px = (prefs.getFloat("plus_x_ratio", 0f) * REF_W).toInt()
        val py = (prefs.getFloat("plus_y_ratio", 0f) * REF_H).toInt()
        if (py - (rows.first() + 26) !in 85..225 || px !in 300..REF_W - 30) {
            setStatus("등록한 + 위치와 첫 번째 집결 줄이 맞지 않음")
            return null
        }

        // Every numeric strip is magnified threefold, separated by a blank band.
        val textByRow = mutableMapOf<Int, MutableList<String>>()
        result.textBlocks.flatMap { it.lines }.forEach { line ->
            val box = line.boundingBox ?: return@forEach
            val idx = box.centerY() / 156
            if (idx in rows.indices) {
                textByRow.getOrPut(idx) { mutableListOf() }.add(line.text)
            }
        }
        val candidates = mutableListOf<Candidate>()
        var anyLevel = false
        var bossCount = 0
        var underLimitCount = 0
        var noPlusCount = 0
        for (index in rows.indices) {
            val raw = textByRow[index].orEmpty().joinToString(" ")
            val fromOcr = parseLevel(raw)
            val fromPixels = knownLevelFromScreenshot(bitmap, rows[index])
            if (fromOcr != null && fromPixels != null && fromOcr != fromPixels) {
                // Disagreement means this row isn't safe to tap.
                continue
            }
            val level = fromOcr ?: fromPixels ?: continue
            anyLevel = true

            // We verify the actual DOJEOK BOSS portrait, not just an Lv number.
            // This rejects cheese-thief and all unrecognized monster portraits.
            if (!matchesRogueBossPortrait(bitmap, rows[index])) continue
            bossCount++
            if (level < 50 || level % 5 != 0 || level > maxLevel()) continue
            underLimitCount++
            val targetY = py + (rows[index] - rows.first())
            if (targetY !in 250..REF_H - 85) continue
            if (!isGreenJoinPlus(bitmap, px, targetY)) {
                noPlusCount++
                continue
            }
            val greenSlots = (0..3).count { i -> isGreenJoinPlus(bitmap, px - 90*i, targetY) }
            candidates += Candidate(level, rows[index] + 26, px, targetY, greenSlots)
        }
        val selected = candidates.minWithOrNull(compareBy<Candidate> { it.availableSlots }.thenBy { it.rowY })
        if (selected == null) {
            val sample = textByRow[0].orEmpty().joinToString(" ").take(24)
            setStatus(when {
                !anyLevel -> "집결 ${rows.size}개, 숫자 OCR 실패 (읽힌 글자: ${sample.ifBlank { "없음" }})"
                bossCount == 0 -> "레벨 확인, 도적보스 그림 불일치 → 제외"
                underLimitCount == 0 -> "도적보스 확인, 설정한 Lv.${maxLevel()} 이하 아님"
                noPlusCount > 0 -> "도적보스 확인, 오른쪽 초록 + 없음"
                else -> "도적보스 집결 위치 검증 실패"
            })
        }
        return selected
    }

    /** OCR often confuses l/I/O with digits in small UI labels. */
    private fun parseLevel(rawText: String): Int? {
        val normalized = rawText.replace(" ", "").replace("\n", "")
            .replace("：", ":").replace("。", ".")
        val match = Regex("(?i)l[vw][.:]?([0-9Oo]{2,3})").find(normalized) ?: return null
        return match.groupValues[1].replace("O", "0").replace("o", "0").toIntOrNull()
    }

    private val bossPortraitMasks: List<Bitmap> by lazy {
        listOf(R.drawable.boss_mask_60, R.drawable.boss_mask_70).map {
            android.graphics.BitmapFactory.decodeResource(resources, it)
        }
    }
    private val levelMasks: List<Pair<Int, Bitmap>> by lazy {
        listOf(60 to R.drawable.level_mask_60, 70 to R.drawable.level_mask_70).map { (lv, id) ->
            lv to android.graphics.BitmapFactory.decodeResource(resources, id)
        }
    }

    /** Foreground-aware silhouette matching: background hue may be blue OR green. */
    private fun matchesRogueBossPortrait(bitmap: Bitmap, top: Int): Boolean =
        bossPortraitMasks.maxOf { mask -> darknessSimilarity(bitmap, mask, 90, top+48, 4) } >= 0.61

    /** Extra fallback for the exact Lv.60/Lv.70 labels seen in user screenshots. */
    private fun knownLevelFromScreenshot(bitmap: Bitmap, top: Int): Int? {
        val matches = levelMasks.map { (lv, mask) ->
            lv to darknessSimilarity(bitmap, mask, 75, top+8, 2)
        }.sortedByDescending { it.second }
        if (matches.first().second < 0.78 || matches.first().second - matches.last().second < 0.12) return null
        return matches.first().first
    }

    private fun darknessSimilarity(image: Bitmap, mask: Bitmap, x: Int, y: Int, step: Int): Double {
        var both = 0
        var either = 0
        for (dy in 0 until mask.height step step) for (dx in 0 until mask.width step step) {
            val color = image.getPixel(x+dx,y+dy)
            val lum = (Color.red(color)*21 + Color.green(color)*72 + Color.blue(color)*7)/100
            val actualDark = lum < 130
            val expectedDark = Color.red(mask.getPixel(dx, dy)) < 128
            if (actualDark && expectedDark) both++
            if (actualDark || expectedDark) either++
        }
        return if (either == 0) 0.0 else both.toDouble()/either
    }

    /**
     * The left rally-card color changes with the target's level/status:
     * blue (common) OR light green (e.g. Lv.60 user screenshot).
     * Sample the clear right edge (x=240), not x=35 where the share icon
     * interrupts the color band for >30 px and broke run detection.
     * The surrounding list is grey; require one long colored strip.
     */
    private fun detectRallyRows(bitmap: Bitmap): List<Int> {
        val starts = mutableListOf<Int>()
        var runStart = -1
        for (y in 230 until REF_H - 120 step 2) {
            val c = bitmap.getPixel(240, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            val blueCard = r < 192 && g - r > 13 && b - r > 30 && b - g > 8
            val greenCard = r > 110 && b > 105 && g > 190 &&
                g - r > 13 && g - b > 14
            val card = blueCard || greenCard
            if (card && runStart < 0) runStart = y
            if ((!card || y >= REF_H - 122) && runStart >= 0) {
                // Crop/scroll can make the final card shorter than the 310px full card.
                if (y - runStart >= 130) starts += runStart
                runStart = -1
            }
        }
        return starts.take(6)
    }

    /**
     * Larger OCR input, containing just the "Lv.60" area.
     * Removes the monster art covering "도적보스" from the OCR frame.
     */
    private fun compactHeaderImage(bitmap: Bitmap, rows: List<Int>): Bitmap {
        val stride = 156
        val combined = Bitmap.createBitmap(306, rows.size*stride, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(combined)
        canvas.drawColor(Color.WHITE)
        rows.forEachIndexed { i, top ->
            val topY = (top+8).coerceIn(0, REF_H-55)
            canvas.drawBitmap(bitmap, Rect(43, topY, 145, topY+43),
                Rect(0, i*stride+5, 306, i*stride+134), null)
        }
        return combined
    }

    /**
     * Check just a 37x37 patch around the calibrated '+' center. Sampling
     * 49 pixels is fast enough for every row and prevents tapping grey
     * placeholders for an already joined/full rally.
     */
    private fun isGreenJoinPlus(bitmap: Bitmap, x: Int, y: Int): Boolean {
        if (x < 35 || x >= REF_W - 35 || y < 35 || y >= REF_H - 35) return false
        var greenCount = 0
        for (dy in -18..18 step 6) for (dx in -18..18 step 6) {
            val c = bitmap.getPixel(x + dx, y + dy)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (g > 135 && g - r > 38 && g - b > 28) greenCount++
        }
        return greenCount >= 12
    }

    private fun normalize(text: String) = text.replace(" ", "").replace("\n", "").trim()
    private fun maxLevel(): Int = prefs.getInt("max_level", 70)

    private fun hasRallySkull(bitmap: Bitmap): Boolean {
        var red = 0
        var light = 0
        var total = 0
        for (y in 930..989 step 3) for (x in 614..686 step 3) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 135 && r > g * 1.4f && r > b * 1.25f) red++
            if (r > 205 && g > 190 && b > 180) light++
            total++
        }
        return red > total * 0.22 && light > total * 0.07
    }

    private fun isEventBackground(bitmap: Bitmap): Boolean {
        // Stable event panel header pixels remain visible even when 3+ cards fill the list.
        val points = listOf(320 to 231, 600 to 211, 350 to 1450)
        return points.count { (x, y) ->
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            r in 165..230 && g in 175..235 && b in 180..240 &&
                kotlin.math.abs(g - r) < 30 && b >= g
        } >= 2
    }

    private fun isRefreshVisible(bitmap: Bitmap): Boolean {
        var yellow = 0
        for (y in 1440..1490 step 5) for (x in 280..425 step 5) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 210 && g in 125..220 && b < 105) yellow++
        }
        return yellow > 100
    }

    private fun isBlueDeployButton(bitmap: Bitmap): Boolean {
        var good = 0
        for ((x, y) in listOf(250 to 1167, 285 to 1183, 350 to 1137,
            430 to 1177, 468 to 1167)) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (b > 170 && b > g + 40 && g > r + 45 && r < 130) good++
        }
        return good >= 4
    }

    private fun readText(bitmap: Bitmap, callback: (Text, List<Int>) -> Unit) {
        val rows = if (stage == Stage.EVENT) detectRallyRows(bitmap) else emptyList()
        if (stage == Stage.EVENT && rows.isEmpty()) {
            setStatus("집결 카드 없음 또는 카드 위치 인식 실패")
            bitmap.recycle()
            schedule(250)
            return
        }
        val inputBitmap = when (stage) {
            Stage.EVENT -> compactHeaderImage(bitmap, rows)
            Stage.DEPLOY -> Bitmap.createBitmap(bitmap, 180, 1070, 360, 200)
            Stage.WORLD -> bitmap
        }
        val startedAt = SystemClock.elapsedRealtime()
        val isLevelScan = stage == Stage.EVENT
        recognizer.process(InputImage.fromBitmap(inputBitmap, 0))
            .addOnSuccessListener {
                if (isLevelScan) {
                    prefs.edit().putLong("last_level_ocr_ms", SystemClock.elapsedRealtime() - startedAt).apply()
                }
                if (capturing) callback(it, rows)
            }
            .addOnFailureListener { setStatus("레벨 OCR 오류 - 참여 보류") }
            .addOnCompleteListener {
                if (inputBitmap !== bitmap) inputBitmap.recycle()
                bitmap.recycle()
                schedule(120)
            }
    }

    private fun captureNormalizedFrame(): Bitmap? {
        val image = try { reader?.acquireLatestImage() } catch (_: Exception) { null } ?: return null
        try {
            val plane = image.planes.firstOrNull() ?: return null
            val rowPadding = plane.rowStride - plane.pixelStride * image.width
            val paddedWidth = image.width + rowPadding / plane.pixelStride
            val tmp = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            val buffer: ByteBuffer = plane.buffer
            buffer.rewind()
            tmp.copyPixelsFromBuffer(buffer)
            val actual = Bitmap.createBitmap(tmp, 0, 0, image.width, image.height)
            tmp.recycle()
            val scaled = Bitmap.createScaledBitmap(actual, REF_W, REF_H, true)
            if (actual !== scaled) actual.recycle()
            return scaled
        } catch (_: Exception) {
            return null
        } finally { image.close() }
    }

    private fun setStatus(message: String) {
        prefs.edit().putString("status", message).apply()
    }

    private fun stopMonitoring(reason: String) {
        capturing = false
        handler.removeCallbacksAndMessages(null)
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        val oldProjection = projection
        projection = null
        try {
            projectionCallback?.let { oldProjection?.unregisterCallback(it) }
            oldProjection?.stop()
        } catch (_: Exception) {}
        projectionCallback = null
        prefs.edit().putBoolean("running", false).putString("status", reason).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (capturing || projection != null) stopMonitoring("서비스 종료")
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}


/*
 * Legacy GitHub Actions build-script compatibility anchors.
 * The existing workflow in the user's repository performs exact string
 * substitutions on an older source version before compiling. These patterns
 * are inert: the current RallyBot runtime above already implements fast
 * scanning, calibrated rightmost + targeting, and per-row OCR spacing.
 * They can be removed after the workflow is switched to a plain ZIP build.
 *
handler.postDelayed(::scanFrame, 1700L)
now - lastActionAt < 1100
if (now - lastActionAt < 300) { schedule(500); return }
if (frame == null) { schedule(500); return }
schedule(1050)
schedule(1000)
schedule(1650)
schedule(2500)
for (x in listOf(620, 530, 440, 349)) {
recognizer.process(InputImage.fromBitmap(bitmap, 0))
                bitmap.recycle()
                schedule(if (stage == Stage.EVENT) 1700 else 1400)
 */
