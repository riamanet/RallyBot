plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.crow.rally"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.crow.rally"
        minSdk = 29
        targetSdk = 34
        versionCode = (project.findProperty("ciVersionCode") as String?)?.toIntOrNull() ?: 10
        versionName = (project.findProperty("ciVersionName") as String?) ?: "1.0.0"
    }

    signingConfigs {
        create("releaseRallyBot") {
            storeFile = file(System.getenv("RALLYBOT_KEYSTORE_PATH") ?: "signing.p12")
            storePassword = System.getenv("RALLYBOT_SIGNING_PASSWORD") ?: ""
            keyAlias = "rallybot"
            keyPassword = System.getenv("RALLYBOT_SIGNING_PASSWORD") ?: ""
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("releaseRallyBot")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Bundled, on-device Korean OCR; screenshots are not sent to a server.
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("androidx.core:core:1.15.0")
}
